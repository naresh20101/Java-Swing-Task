/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pojos;
import java.util.*;

/**
 *
 * @author Dell
 */
public class Student {
   private int std_id;
   private String std_name;
   private String Fathers_name;
   private String Gender;
   private String Address;
   private int Phone_No;
    private String Date_Of_Birth;
    private DistrictBean districtBean;

    public DistrictBean getDistrictBean() {
        return districtBean;
    }

    public void setDistrictBean(DistrictBean districtBean) {
        this.districtBean = districtBean;
    }
    

    public String getDate_Of_Birth() {
        return Date_Of_Birth;
    }

    public void setDate_Of_Birth(String Date_Of_Birth) {
        this.Date_Of_Birth = Date_Of_Birth;
    }
 

    public int getStd_id() {
        return std_id;
    }

    public void setStd_id(int std_id) {
        this.std_id = std_id;
    }

    public String getStd_name() {
        return std_name;
    }

    public void setStd_name(String std_name) {
        this.std_name = std_name;
    }

    public String getFathers_name() {
        return Fathers_name;
    }

    public void setFathers_name(String Fathers_name) {
        this.Fathers_name = Fathers_name;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public int getPhone_No() {
        return Phone_No;
    }

    public void setPhone_No(int Phone_No) {
        this.Phone_No = Phone_No;
    }

  
    
}
