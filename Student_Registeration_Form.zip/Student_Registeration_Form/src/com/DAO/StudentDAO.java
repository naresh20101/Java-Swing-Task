/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.DAO;

import com.pojos.Student;
import java.util.*;
import java.sql.ResultSet;

/**
 *
 * @author Dell
 */
public interface StudentDAO {
    public Integer addStudent(Student student);
    public void updateCountry(Student student);
    public List<Student> getStudents();
    public void deleteStudent(Integer countryId);
    public Student getStudentById(Integer id);
    public ResultSet getAllCountries();
}
    

