/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.DAO;

import com.pojos.DistrictBean;
import java.util.List;

/**
 *
 * @author Dell
 */
public interface DistrictBeanDAO {
    public List<DistrictBean> getAllDepartments();
    public Integer getDistrictIdByName(String dist_name);
    public DistrictBean getDistrictById(Integer dist_id);
    
    
}
