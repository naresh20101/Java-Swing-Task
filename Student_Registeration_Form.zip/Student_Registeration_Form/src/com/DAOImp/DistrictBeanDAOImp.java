/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.DAOImp;

import com.DAO.DistrictBeanDAO;
import com.dbManager.dbConnection;
import com.pojos.DistrictBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Dell
 */
public class DistrictBeanDAOImp implements DistrictBeanDAO{
   static Connection con = dbConnection.getDbConnection();

    @Override
    public List<DistrictBean> getAllDepartments() {
        List<DistrictBean> list=new ArrayList<>();
        try {
            String query = "select * from district";
            PreparedStatement smt = con.prepareStatement(query);
            ResultSet rst = smt.executeQuery();
            while(rst.next()){
                DistrictBean db=new DistrictBean();
                db.setDist_id(rst.getInt("District_id"));
                db.setDist_name(rst.getString("District_name"));
                list.add(db);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        return list;
    }

    @Override
    public Integer getDistrictIdByName(String dist_name) {
         Integer dist_Id=0;
        try {
            String delete = "select District_id from district where District_name=?";
            PreparedStatement smt = con.prepareStatement(delete);
            smt.setString(1, dist_name);
            ResultSet rst = smt.executeQuery();
            while(rst.next()){
                dist_Id=rst.getInt("District_id");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return dist_Id;
        
    }

  @Override
public DistrictBean getDistrictById(Integer dist_id) {
DistrictBean db=new DistrictBean();
        try {
            String delete = "select * from district where District_id=?";
            PreparedStatement smt = con.prepareStatement(delete);
            smt.setInt(1, dist_id);
            ResultSet rst = smt.executeQuery();
            while(rst.next()){
                db.setDist_id(rst.getInt("District_id"));
                db.setDist_name(rst.getString("District_name"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        return db;
    }
        
}



