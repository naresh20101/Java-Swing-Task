/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.DAOImp;

import com.DAO.StudentDAO;
import com.dbManager.dbConnection;
import com.pojos.DistrictBean;
import com.pojos.Student;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Dell
 */
public class StudentDAOImp implements StudentDAO{
    static Connection con = dbConnection.getDbConnection();

    @Override
    public Integer addStudent(Student student) {
       Integer row=null;
      try
      {
          Connection con1 = dbConnection.getDbConnection();
            String addQuery = "insert into student_form(std_id,std_name,Fathers_name,Gender,Address,Phone_No,Date_Of_Birth,District_id) values(?,?,?,?,?,?,?,?)";
            PreparedStatement smt = con1.prepareStatement(addQuery);
            smt.setInt(1,student.getStd_id());
            smt.setString(2, student.getStd_name());
            smt.setString(3,student.getFathers_name());
            smt.setString(4,student.getGender());
            smt.setString(5,student.getAddress());
            smt.setInt(6,student.getPhone_No());
            smt.setString(7,student.getDate_Of_Birth());
            smt.setInt(8, student.getDistrictBean().getDist_id());
               
               
            row = smt.executeUpdate();
            System.out.println("Row : "+row);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return row;
    }

    @Override
    public void updateCountry(Student student) {
      try {
            String update = "update student_form set std_name=?,Fathers_name=?,Gender=?,Address=?,Phone_No=?,Date_Of_Birth=?,District_id=? where std_id=?";
            PreparedStatement smt = con.prepareStatement(update);
            smt.setString(1, student.getStd_name());
            smt.setString(2,student.getFathers_name());
            smt.setString(3,student.getGender());
            smt.setString(4,student.getAddress());
            smt.setInt(5,student.getPhone_No());
            smt.setString(6,student.getDate_Of_Birth());
            smt.setInt(7,student.getDistrictBean().getDist_id());
            smt.setInt(8,student.getStd_id());
            smt.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

   
    @Override
    public List<Student> getStudents() {
        List<Student> list=new ArrayList<>();
        Connection con2 = dbConnection.getDbConnection();
        try {
            String query = "select * from student_form";
            PreparedStatement smt = con2.prepareStatement(query);
            ResultSet rst = smt.executeQuery();
            while(rst.next()){
                Student s=new Student();
                s.setStd_id(rst.getInt("std_id"));
                s.setStd_name(rst.getString("std_name"));
                s.setFathers_name(rst.getString("Fathers_name"));
                s.setGender(rst.getString("Gender"));
                s.setAddress(rst.getString("Address"));
                s.setDate_Of_Birth(rst.getString("Date_Of_Birth"));
                DistrictBean db=new DistrictBean();
                db.setDist_id(rst.getInt("District_id"));
                s.setDistrictBean(db);
                list.add(s);
            }
        } catch (Exception ex) {
    }
        return list;
 }

     @Override
    public void deleteStudent(Integer countryId) {
        try
        {
            
            String delete = "delete from student_form where std_id=?";
            PreparedStatement smt = con.prepareStatement(delete);
            smt.setInt(1, countryId);
            smt.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        }
  
    
  @Override
    public Student getStudentById(Integer id) {
       Student s=new Student();
        try {
            String delete = "select * from student_form where std_id=?";
            PreparedStatement smt = con.prepareStatement(delete);
            smt.setInt(1, id);
            ResultSet rst = smt.executeQuery();
            while(rst.next()){
                s.setStd_id(rst.getInt("std_id"));
                s.setStd_name(rst.getString("std_name"));
                s.setFathers_name(rst.getString("Fathers_name"));
                s.setGender(rst.getString("Gender"));
                s.setAddress(rst.getString("Address"));
                s.setPhone_No(rst.getInt("Phone_No"));
                s.setDate_Of_Birth(rst.getString("Date_Of_Birth"));
               
                
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        return s;
   
    }

    @Override
    public ResultSet getAllCountries() {
         ResultSet resultSet=null;
        try {
            String query = "select * from student_form";
            PreparedStatement smt = con.prepareStatement(query);
            resultSet = smt.executeQuery();
           
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return resultSet;
    }
    
    }
   
