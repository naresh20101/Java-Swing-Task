/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student_registeration_form;

import com.DAO.StudentDAO;
import com.DAOImp.StudentDAOImp;
import com.pojos.Student;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Dell
 */
public class Student_Registeration_Form {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      try
      {
          Scanner s=new Scanner(System.in);
          Student student=new Student();
        StudentDAO stdDAO= new StudentDAOImp();
        Integer std_id=s.nextInt();
        student.setStd_id(std_id);
        String std_name=s.next();
         student.setStd_name(std_name);
        
        String Fathers_name=s.next();
         student.setFathers_name(Fathers_name);
        String Gender =s.next();
        student.setGender(Gender);
        String Address=s.next();
        student.setAddress(Address);
      
        Integer Phone_No=s.nextInt();
        student.setPhone_No(Phone_No);
        String date=s.next();
        student.setDate_Of_Birth(date);
        int row=stdDAO.addStudent(student);
          if (row > 0) {
                        System.out.println("Data SuccessFully Added.");
                    } else {
                        System.out.println("Error");
                    }
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }

        
    }
    
}
